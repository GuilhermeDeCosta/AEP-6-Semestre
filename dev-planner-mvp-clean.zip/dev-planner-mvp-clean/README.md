# Dev Planner — MVP (Node.js + Express + MongoDB)

Estrutura limpa e funcional do backend do Dev Planner.

## Como usar

1. Copie `.env.example` para `.env` e configure `MONGODB_URI` e `JWT_SECRET`.
2. `npm install`
3. `npm run dev`
4. Teste os endpoints com `tests/api.http` ou Postman/Thunder Client.

Endpoints principais:
- POST /api/auth/register
- POST /api/auth/login
- POST /api/projects
- GET  /api/projects
- GET  /api/projects/:id
- POST /api/projects/:projectId/tasks
- PATCH /api/tasks/:id/move
