const User = require('../models/User');
const Project = require('../models/Project');
const Task = require('../models/Task');

async function seed() {
  await User.deleteMany();
  await Project.deleteMany();
  await Task.deleteMany();
  const u = new User({ name: 'Teste', email: 'teste@dev.com', password: '123456' });
  await u.save();
  const p = new Project({ title: 'Projeto Exemplo', description: 'Projeto para demonstração', owner: u._id });
  await p.save();
  const t1 = new Task({ title: 'Criar repositório', project: p._id });
  const t2 = new Task({ title: 'Implementar backend', project: p._id, status: 'doing' });
  const t3 = new Task({ title: 'Escrever relatório', project: p._id, status: 'todo' });
  await t1.save(); await t2.save(); await t3.save();
  console.log('Seed finalizada');
}

module.exports = seed;
