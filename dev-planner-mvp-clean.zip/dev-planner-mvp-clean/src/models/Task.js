const mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  status: { type: String, enum: ['todo','doing','done'], default: 'todo' },
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
  assignee: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  doneAt: { type: Date }
});

TaskSchema.pre('save', function(next) {
  if (this.isModified('status') && this.status === 'done') {
    this.doneAt = new Date();
  }
  next();
});

module.exports = mongoose.model('Task', TaskSchema);
