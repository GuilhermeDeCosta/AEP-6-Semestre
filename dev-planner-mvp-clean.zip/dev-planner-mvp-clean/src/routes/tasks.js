const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const Project = require('../models/Project');
const auth = require('../middlewares/auth');

router.use(auth);

router.post('/:projectId/tasks', async (req, res) => {
  try {
    const { title, description, assignee } = req.body;
    const project = await Project.findById(req.params.projectId);
    if (!project) return res.status(404).json({ message: 'Projeto não encontrado' });
    const task = new Task({ title, description, project: project._id, assignee });
    await task.save();
    res.status(201).json(task);
  } catch (err) { res.status(500).json({ message: 'Erro ao criar tarefa' }); }
});

router.put('/:id', async (req, res) => {
  try {
    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(task);
  } catch (err) { res.status(500).json({ message: 'Erro ao atualizar tarefa' }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: 'Tarefa removida' });
  } catch (err) { res.status(500).json({ message: 'Erro ao remover tarefa' }); }
});

router.patch('/:id/move', async (req, res) => {
  try {
    const { status } = req.body;
    if (!['todo','doing','done'].includes(status)) return res.status(400).json({ message: 'Status inválido' });
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Tarefa não encontrada' });
    task.status = status;
    if (status === 'done') task.doneAt = new Date();
    else task.doneAt = undefined;
    await task.save();
    res.json(task);
  } catch (err) { res.status(500).json({ message: 'Erro ao mover tarefa' }); }
});

module.exports = router;
