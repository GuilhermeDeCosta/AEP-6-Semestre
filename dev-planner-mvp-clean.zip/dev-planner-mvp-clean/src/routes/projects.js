const express = require('express');
const router = express.Router();
const Project = require('../models/Project');
const Task = require('../models/Task');
const auth = require('../middlewares/auth');

router.use(auth);

router.post('/', async (req, res) => {
  try {
    const { title, description } = req.body;
    const project = new Project({ title, description, owner: req.user._id });
    await project.save();
    res.status(201).json(project);
  } catch (err) { res.status(500).json({ message: 'Erro ao criar projeto' }); }
});

router.get('/', async (req, res) => {
  try {
    const projects = await Project.find({ $or: [ { owner: req.user._id }, { members: req.user._id } ] });
    res.json(projects);
  } catch (err) { res.status(500).json({ message: 'Erro ao buscar projetos' }); }
});

router.get('/:id', async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Projeto não encontrado' });
    const tasks = await Task.find({ project: project._id });
    res.json({ project, tasks });
  } catch (err) { res.status(500).json({ message: 'Erro ao buscar projeto' }); }
});

router.put('/:id', async (req, res) => {
  try {
    const project = await Project.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(project);
  } catch (err) { res.status(500).json({ message: 'Erro ao atualizar projeto' }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await Task.deleteMany({ project: req.params.id });
    await Project.findByIdAndDelete(req.params.id);
    res.json({ message: 'Projeto removido' });
  } catch (err) { res.status(500).json({ message: 'Erro ao remover projeto' }); }
});

module.exports = router;
